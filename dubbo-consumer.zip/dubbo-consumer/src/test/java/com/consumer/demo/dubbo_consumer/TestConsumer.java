package com.consumer.demo.dubbo_consumer;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.inter.face.demo.DubboService;

public class TestConsumer {
public static void main(String[] args) {
	 ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("classpath:applicationConsumer.xml");  
     context.start();  
     DubboService demoService = (DubboService)context.getBean("dubboservice");   
     demoService.print();
}
}
