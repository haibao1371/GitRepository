package com.dubbo.provider.dubbo_provider;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestProvider {
public static void main(String[] args) throws Exception {
	//获得Spring中定义的bean对象，此代码就是读取我们配置的服务提供者文件
	ClassPathXmlApplicationContext context=  
            new ClassPathXmlApplicationContext("classpath:applicationProvider.xml");
	//
	context.start();
    System.out.println("任意键退出");   
    System.in.read();  
}
}
