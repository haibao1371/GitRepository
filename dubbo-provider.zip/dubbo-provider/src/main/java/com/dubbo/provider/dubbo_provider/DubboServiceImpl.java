package com.dubbo.provider.dubbo_provider;

import org.springframework.stereotype.Service;

import com.inter.face.demo.DubboService;
public class DubboServiceImpl implements DubboService {
	public void print() {
		System.out.println("我是服务提供者");
	} 
}
