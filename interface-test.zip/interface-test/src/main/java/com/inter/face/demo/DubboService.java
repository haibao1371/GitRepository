package com.inter.face.demo;

public interface DubboService {
public abstract void print();
}
